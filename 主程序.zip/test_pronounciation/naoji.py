# -*- coding: UTF-8 -*-
# coding=utf-8
import pylsl
import threading
import time
import paho.mqtt.client as mqtt
import json
import hmac
import hashlib
import logging
from typing import Optional, Callable
import os

CA_CERT_PEM = """
-----BEGIN CERTIFICATE-----
MIIDxTCCAq2gAwIBAgIBADANBgkqhkiG9w0BAQsFADCBgzELMAkGA1UEBhMCVVMx
EDAOBgNVBAgTB0FyaXpvbmExEzARBgNVBAcTClNjb3R0c2RhbGUxGjAYBgNVBAoT
EUdvRGFkZHkuY29tLCBJbmMuMTEwLwYDVQQDEyhHbyBEYWRkeSBSb290IENlcnRp
ZmljYXRlIEF1dGhvcml0eSAtIEcyMB4XDTA5MDkwMTAwMDAwMFoXDTM3MTIzMTIz
NTk1OVowgYMxCzAJBgNVBAYTAlVTMRAwDgYDVQQIEwdBcml6b25hMRMwEQYDVQQH
EwpTY290dHNkYWxlMRowGAYDVQQKExFHb0RhZGR5LmNvbSwgSW5jLjExMC8GA1UE
AxMoR28gRGFkZHkgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgLSBHMjCCASIw
DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAL9xYgjx+lk09xvJGKP3gElY6SKD
E6bFIEMBO4Tx5oVJnyfq9oQbTqC023CYxzIBsQU+B07u9PpPL1kwIuerGVZr4oAH
/PMWdYA5UXvl+TW2dE6pjYIT5LY/qQOD+qK+ihVqf94Lw7YZFAXK6sOoBJQ7Rnwy
DfMAZiLIjWltNowRGLfTshxgtDj6AozO091GB94KPutdfMh8+7ArU6SSYmlRJQVh
GkSBjCypQ5Yj36w6gZoOKcUcqeldHraenjAKOc7xiID7S13MMuyFYkMlNAJWJwGR
tDtwKj9useiciAF9n9T521NtYJ2/LOdYq7hfRvzOxBsDPAnrSTFcaUaz4EcCAwEA
AaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMCAQYwHQYDVR0OBBYE
FDqahQcQZyi27/a9BUFuIMGU2g/eMA0GCSqGSIb3DQEBCwUAA4IBAQCZ21151fmX
WWcDYfF+OwYxdS2hII5PZYe096acvNjpL9DbWu7PdIxztDhC2gV7+AJ1uP2lsdeu
9tfeE8tTEH6KRtGX+rcuKxGrkLAngPnon1rpN5+r5N9ss4UXnT3ZJE95kTXWXwTr
gIOrmgIttRD02JDHBHNA7XIloKmf7J6raBKZV8aPEjoJpL1E/QYVN8Gb5DKj7Tjo
2GTzLH4U/ALqn83/B2gX2yKQOC16jdFU8WnjXzPKej17CuPKf1855eJ1usV2GDPO
LPAvTK33sefOT6jEm0pUBsV/fdUID+Ic/n4XuKxe9tQWskMJDE32p2u0mYRlynqI
4uJEvlz36hz1
-----END CERTIFICATE-----
"""

class DataCollector:
    """从lsl流采集脑电数据类,处理实时数据"""
    
    def __init__(self, stream_types=None):
        """
        初始化数据采集器
        :param stream_types: 要采集的数据流类型列表，默认为['AlphaAbs', 'BetaAbs', 'DeltaAbs']
        """

        self.stream_types = stream_types or ['AlphaAbs', 'BetaAbs', 'DeltaAbs']
        self.inlets = {}
        self.stream_details = {}
        self.running = False       # 运行状态标志
        
    def setup_streams(self):
        """查找并设置所有类型的数据流"""
        for stream_type in self.stream_types:
            streams = pylsl.resolve_byprop("type", stream_type, timeout=2.0)
            if streams:
                print(f"找到 {stream_type} 数据流")
                stream_info = streams[0]
                inlet = pylsl.StreamInlet(stream_info)
                self.inlets[stream_type] = inlet

                # 获取采样率
                nominal_srate = stream_info.nominal_srate()
                if nominal_srate <= 0:  # 如果采样率未指定，设置默认值
                    nominal_srate = 1.0

                self.stream_details[stream_type] = {
                    'channel_count': stream_info.channel_count(),   # 通道数
                    'nominal_srate': nominal_srate,
                    'channel_format': stream_info.channel_format()
                }

                print(f"数据流信息：数据名称={stream_type} 通道数={stream_info.channel_count()}, 采样率={nominal_srate}")
        
        if not self.inlets:
            print("未找到任何数据流。请确保设备已连接并处于运行状态。")
            return False
        return True
    
    def start_collecting(self, callback=None):
        """
        开始采集数据
        :param callback: 数据处理回调函数，接收一个包含数据的字典
        """
        if not self.inlets:
            if not self.setup_streams():
                return False
        
        self.running = True
        print("[脑机] 开始采集数据...")

        try:
            while self.running:
                values = {
                    "AlphaAbs": None,
                    "BetaAbs": None,
                    "DeltaAbs": None,
                    "AttentionValue": None,
                }
                
                # 从每个数据流读取数据
                for stream_type, inlet in self.inlets.items():
                    # 根据采样率计算应该读取的样本数
                    nominal_srate = self.stream_details[stream_type]['nominal_srate']
                    chunk_size = max(1, int(nominal_srate * 0.1))  # 每 0.1 秒的数据量

                    # 使用 pull_chunk 读取多个样本
                    samples, timestamps = inlet.pull_chunk(max_samples=chunk_size, timeout=0.0)

                    if samples:
                        # 计算样本平均值
                        channel_avg = [sum(channel_values) / len(channel_values) for channel_values in zip(*samples)]
                        values[stream_type] = sum(channel_avg) / len(channel_avg)
                
                # 计算注意力值（只在所有必要数据都存在时计算）
                if all(values.get(t) for t in ['AlphaAbs', 'BetaAbs', 'DeltaAbs']):
                    values["AttentionValue"] = values["BetaAbs"] / (values["AlphaAbs"] + values["DeltaAbs"])
                    
                    # 如果有回调函数，则调用
                    if callback:
                        callback(values)
                
                time.sleep(0.1)  # 适当降低CPU占用
                
        except Exception as e:
            print(f"[脑机] 采集异常: {e}")
        finally:
            self.stop_collecting()
    
    def stop_collecting(self):
        """停止数据采集"""
        self.running = False
        print("停止数据采集，关闭所有数据流入口。")
        for inlet in self.inlets.values():
            inlet.close_stream()
        self.inlets = {}


class AttentionPublisher:
    """专注度数据上传类"""
    
    def __init__(self, device_id: str, device_secret: str):
        """
        初始化MQTT管理器
        :param device_id: 涂鸦设备ID
        :param device_secret: 设备密钥(32位)
        """
        self.device_id = device_id
        self.device_secret = device_secret
        self.client = None
        self.connected = False
        self.last_error = None
        self.ca_cert = self._generate_temp_ca_file()
        
        # 配置日志
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger("AttentionPublisher")
        
    def _generate_temp_ca_file(self) -> str:
        """生成临时CA证书文件"""
        import tempfile
        import os
        
        try:
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.pem') as f:
                f.write(CA_CERT_PEM)
                return f.name
        except Exception as e:
            self.logger.error(f"创建CA临时文件失败: {e}")
            raise

    def _generate_auth_params(self) -> tuple:
        """生成MQTT连接认证参数"""
        timestamp = str(int(time.time()))
        sign_content = f"deviceId={self.device_id},timestamp={timestamp},secureMode=1,accessType=1"
        
        # 生成签名
        signature = hmac.new(
            key=self.device_secret.encode('utf-8'),
            msg=sign_content.encode('utf-8'),
            digestmod=hashlib.sha256
        ).hexdigest()
        
        username = f"{self.device_id}|signMethod=hmacSha256,timestamp={timestamp},secureMode=1,accessType=1"
        password = signature
        
        self.logger.debug(f"Auth Params - Username: {username}, Password: {password}")
        return username, password

    def _on_connect(self, client, userdata, flags, rc):
        """MQTT连接回调"""
        if rc == 0:
            self.connected = True
            self.last_error = None
            self.logger.info("MQTT连接成功")
            
            # 订阅默认主题
            client.subscribe(f"tylink/{self.device_id}/#", qos=1)
        else:
            self.connected = False
            error_msg = mqtt.connack_string(rc)
            self.last_error = error_msg
            self.logger.error(f"MQTT连接失败: {error_msg}")

    def _on_disconnect(self, client, userdata, rc):
        """MQTT断开回调"""
        self.connected = False
        if rc != 0:
            self.last_error = f"意外断开: {mqtt.error_string(rc)}"
            self.logger.warning(f"MQTT连接断开: {self.last_error}")
            
    def connect(self, max_retries: int = 3, retry_interval: float = 5.0) -> bool:
        """
        连接到涂鸦MQTT服务器
        :param max_retries: 最大重试次数
        :param retry_interval: 重试间隔(秒)
        :return: 是否连接成功
        """
        for attempt in range(1, max_retries + 1):
            try:
                # 生成认证参数
                username, password = self._generate_auth_params()
                
                # 创建客户端
                self.client = mqtt.Client(
                    client_id=f"tuyalink_{self.device_id}",
                    protocol=mqtt.MQTTv311,
                    transport="tcp"
                )
                
                # 设置回调
                self.client.on_connect = self._on_connect
                self.client.on_disconnect = self._on_disconnect
                
                # 配置TLS
                self.client.tls_set(
                    ca_certs=self.ca_cert,
                    cert_reqs=mqtt.ssl.CERT_REQUIRED,
                    tls_version=mqtt.ssl.PROTOCOL_TLSv1_2
                )
                self.client.tls_insecure_set(False)
                
                # 设置认证
                self.client.username_pw_set(username, password)
                
                # 连接服务器
                self.logger.info(f"尝试连接MQTT服务器(第{attempt}次)...")
                self.client.connect("m1.tuyacn.com", 8883, 60)
                self.client.loop_start()
                
                # 等待连接完成
                start_time = time.time()
                while not self.connected and (time.time() - start_time) < 10:
                    time.sleep(0.1)
                
                if self.connected:
                    return True
                    
            except Exception as e:
                self.last_error = str(e)
                self.logger.error(f"连接尝试{attempt}失败: {e}")
                
            if attempt < max_retries:
                time.sleep(retry_interval)
        
        return False

    def publish_attention(self, attention_value: float) -> bool:
        """
        发布专注度数据到涂鸦云
        :param attention_value: 专注度值(0-100)
        :return: 是否发布成功
        """
        if not self.connected:
            # 尝试重新连接
            self.logger.warning("MQTT未连接，尝试重新连接...")
            if not self.connect():
                self.logger.error("重新连接失败，无法发布数据")
                return False
            
        try:
            current_time = str(int(time.time())) + "000"
            
            # 严格对齐涂鸦云的JSON结构
            # payload = {
            #     "msgId": f"attention_data_{current_time}",
            #     "time": current_time,q
            #     "data": {
            #         "attention": {
            #             "value": str(round(attention_value, 2)),
            #             "time": current_time
            #         }
            #     }
            # }
            
            # payload_str = json.dumps(payload)

            # 构建payload字符串（使用字符串拼接方式）
            payload = "{"
            payload += "\"msgId\":\"attention_data_" + current_time + "\","
            payload += "\"time\":\"" + current_time + "000\","

            payload += "\"data\":{"
            payload += "\"attention_value\":{"
            payload += "\"value\":\"" + str(round(attention_value, 2)) + "\","
            payload += "\"time\":\"" + current_time + "000\""
            payload += "}"
            payload += "}"
            payload += "}"

            topic = f"tylink/{self.device_id}/thing/property/report"
            result = self.client.publish(topic, payload, qos=1)
            
            if result.rc != mqtt.MQTT_ERR_SUCCESS:
                self.logger.error(f"发布失败: {mqtt.error_string(result.rc)}")
                # 发布失败后断开连接，下次发布时会尝试重连
                self.disconnect()
                return False
                
            self.logger.info(f"专注度数据已发布: {attention_value:.2f}")
            return True
            
        except Exception as e:
            self.last_error = str(e)
            self.logger.error(f"发布消息异常: {e}")
            # 发生异常后断开连接，下次发布时会尝试重连
            self.disconnect()
            return False

    def disconnect(self):
        """断开MQTT连接"""
        if self.client:
            try:
                self.client.loop_stop()
                self.client.disconnect()
                self.connected = False
                self.logger.info("MQTT连接已断开")
            except Exception as e:
                self.logger.error(f"断开连接时出错: {e}")
                
    def __del__(self):
        """析构函数确保资源清理"""
        self.disconnect()
        try:
            if self.ca_cert and os.path.exists(self.ca_cert):
                os.unlink(self.ca_cert)
        except:
            pass


class EEGMonitor:
    """脑电监测模块（只采集不上传）"""
    
    def __init__(self, device_id, device_secret):
        self.device_id = device_id
        self.device_secret = device_secret
        self.collector = DataCollector()  # 数据采集器
        self.attention_values = []      # 专注度数据缓存
        self.last_attention_value = None
        self.running = False
        self.is_connected = False  # 唯一需要的状态

    def start(self):
        """开始采集脑电数据"""
        if not self.collector.setup_streams():
            print("[脑机] 无法连接脑电设备")
            return
            
        self.running = True
        print("[脑机] 开始采集脑电数据...")
        self.collector.start_collecting(callback=self._process_eeg_data)
        return True

    def stop(self):
        """停止采集"""
        self.running = False
        self.collector.stop_collecting()
        print("[脑机] 已停止采集")

    def _process_eeg_data(self, values):
        """处理脑电数据（仅计算不上传）"""

        """处理脑电数据（确保保留2位小数）"""
        if values.get("AttentionValue") is not None:
            raw_value = (values["AttentionValue"] / (1 + values["AttentionValue"])) * 100
            self.last_attention_value = round(raw_value, 2)  # 幅值并强制保留2位小数

            # 实施打印数据
            print(f"[脑机] 实时专注度: {self.last_attention_value}%")
            
            # 存储数据用于平均值计算
            self.attention_values.append(self.last_attention_value)
            if len(self.attention_values) > 10:            # 保留最近10秒数据
                self.attention_values.pop(0)


    def check_connection(self):
        """检测设备是否连接"""
        try:
            streams = pylsl.resolve_streams()
            self.is_connected = any(s.type() in ['AlphaAbs', 'BetaAbs', 'DeltaAbs'] for s in streams)
            return self.is_connected
        except:
            self.is_connected = False
            return False

    def prepare_upload_data(self):
        """准备待上传的脑电数据（由主程序调用）"""
        if not self.attention_values:
            return False
            
        try:
            # 1. 计算平均专注度
            avg_attention = sum(self.attention_values) / len(self.attention_values)
            
            # 2. 生成上传数据包
            current_time = str(int(time.time())) + "000"
            payload = {
                "msgId": "eeg_data_report",
                "time": current_time,
                "data": {
                    "attention": {
                        "value": f"{avg_attention:.2f}",
                        "time": current_time
                    }
                }
            }
            return True, json.dumps(payload)
            
        except Exception as e:
            print(f"[脑机] 数据打包失败: {e}")
            return False

# if __name__ == "__main__":
#     monitor = EEGMonitor()
#     try:
#         monitor.start()
#     except Exception as e:
#         monitor.stop()   