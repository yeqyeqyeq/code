import tkinter as tk
import tkinter.messagebox as messagebox
from PIL import Image, ImageTk
import sqlite3
import numpy as np
import asyncio
from pathlib import Path
import tempfile
import edge_tts
from pygame import mixer
import uuid
import threading
import os
import random
from collections import deque
from datetime import datetime
import paho.mqtt.client as mqtt
import time
import json
import hmac
import hashlib
import logging
from typing import Callable
# from RKLLM_deepseek import RKLLM
# from typing import List
from naoji import EEGMonitor

# 证书
CA_CERT_PEM = """
-----BEGIN CERTIFICATE-----
MIIDxTCCAq2gAwIBAgIBADANBgkqhkiG9w0BAQsFADCBgzELMAkGA1UEBhMCVVMx
EDAOBgNVBAgTB0FyaXpvbmExEzARBgNVBAcTClNjb3R0c2RhbGUxGjAYBgNVBAoT
EUdvRGFkZHkuY29tLCBJbmMuMTEwLwYDVQQDEyhHbyBEYWRkeSBSb290IENlcnRp
ZmljYXRlIEF1dGhvcml0eSAtIEcyMB4XDTA5MDkwMTAwMDAwMFoXDTM3MTIzMTIz
NTk1OVowgYMxCzAJBgNVBAYTAlVTMRAwDgYDVQQIEwdBcml6b25hMRMwEQYDVQQH
EwpTY290dHNkYWxlMRowGAYDVQQKExFHb0RhZGR5LmNvbSwgSW5jLjExMC8GA1UE
AxMoR28gRGFkZHkgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgLSBHMjCCASIw
DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAL9xYgjx+lk09xvJGKP3gElY6SKD
E6bFIEMBO4Tx5oVJnyfq9oQbTqC023CYxzIBsQU+B07u9PpPL1kwIuerGVZr4oAH
/PMWdYA5UXvl+TW2dE6pjYIT5LY/qQOD+qK+ihVqf94Lw7YZFAXK6sOoBJQ7Rnwy
DfMAZiLIjWltNowRGLfTshxgtDj6AozO091GB94KPutdfMh8+7ArU6SSYmlRJQVh
GkSBjCypQ5Yj36w6gZoOKcUcqeldHraenjAKOc7xiID7S13MMuyFYkMlNAJWJwGR
tDtwKj9useiciAF9n9T521NtYJ2/LOdYq7hfRvzOxBsDPAnrSTFcaUaz4EcCAwEA
AaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMCAQYwHQYDVR0OBBYE
FDqahQcQZyi27/a9BUFuIMGU2g/eMA0GCSqGSIb3DQEBCwUAA4IBAQCZ21151fmX
WWcDYfF+OwYxdS2hII5PZYe096acvNjpL9DbWu7PdIxztDhC2gV7+AJ1uP2lsdeu
9tfeE8tTEH6KRtGX+rcuKxGrkLAngPnon1rpN5+r5N9ss4UXnT3ZJE95kTXWXwTr
gIOrmgIttRD02JDHBHNA7XIloKmf7J6raBKZV8aPEjoJpL1E/QYVN8Gb5DKj7Tjo
2GTzLH4U/ALqn83/B2gX2yKQOC16jdFU8WnjXzPKej17CuPKf1855eJ1usV2GDPO
LPAvTK33sefOT6jEm0pUBsV/fdUID+Ic/n4XuKxe9tQWskMJDE32p2u0mYRlynqI
4uJEvlz36hz1
-----END CERTIFICATE-----
"""

# 线上tts
class OnlineTTS:
    def __init__(self):
        mixer.init(frequency=22050, size=-16, channels=2, buffer=4096)
        self.current_file = None
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        self._clean_old_files()

    def _clean_old_files(self):
        for old_file in Path(tempfile.gettempdir()).glob("speech_*.mp3"):
            try:
                old_file.unlink()
            except:
                pass

    def _run_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    async def _async_speak(self, text, voice="en-US-AriaNeural"):
        try:
            if mixer.music.get_busy():
                mixer.music.fadeout(500)
                await asyncio.sleep(0.5)
                
            communicate = edge_tts.Communicate(text, voice)
            temp_file = Path(tempfile.gettempdir()) / f"speech_{uuid.uuid4().hex}.mp3"
            await communicate.save(str(temp_file))
            
            mixer.music.load(str(temp_file))
            mixer.music.play()
            
            if self.current_file and os.path.exists(self.current_file):
                os.unlink(self.current_file)
            self.current_file = temp_file
            
        except Exception as e:
            print(f"语音播放错误: {e}")

    def speak(self, text):
        if text:  # 确保有文本内容才播放
            asyncio.run_coroutine_threadsafe(
                self._async_speak(text), 
                self.loop
            )
        
    def cleanup(self):
        if mixer.get_init():
            mixer.music.stop()
            mixer.quit()
        if self.current_file and os.path.exists(self.current_file):
            try:
                os.unlink(self.current_file)
            except:
                pass
        self.loop.call_soon_threadsafe(self.loop.stop)

# 封装涂鸦云MQTT连接管理的完整类
class TuyaMQTTManager:
    
    def __init__(self, device_id: str, device_secret: str):
        """
        初始化MQTT管理器
        :param device_id: 涂鸦设备ID
        :param device_secret: 设备密钥(32位)
        """
        self.device_id = device_id
        self.device_secret = device_secret
        self.client = None
        self.connected = False
        self.last_error = None
        self.ca_cert = self._generate_temp_ca_file()
        
        # 配置日志
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger("TuyaMQTT")
        
        # 回调函数存储
        self.message_callbacks = []
        
    def _generate_temp_ca_file(self) -> str:
        """生成临时CA证书文件"""
        import tempfile
        import os
        
        try:
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.pem') as f:
                f.write(CA_CERT_PEM)
                return f.name
        except Exception as e:
            self.logger.error(f"创建CA临时文件失败: {e}")
            raise

    def _generate_auth_params(self) -> tuple:
        """生成MQTT连接认证参数"""
        timestamp = str(int(time.time()))
        sign_content = f"deviceId={self.device_id},timestamp={timestamp},secureMode=1,accessType=1"
        
        # 生成签名
        signature = hmac.new(
            key=self.device_secret.encode('utf-8'),
            msg=sign_content.encode('utf-8'),
            digestmod=hashlib.sha256
        ).hexdigest()
        
        username = f"{self.device_id}|signMethod=hmacSha256,timestamp={timestamp},secureMode=1,accessType=1"
        password = signature
        
        self.logger.debug(f"Auth Params - Username: {username}, Password: {password}")
        return username, password

    def _on_connect(self, client, userdata, flags, rc):
        """MQTT连接回调"""
        if rc == 0:
            self.connected = True
            self.last_error = None
            self.logger.info("MQTT连接成功")
            
            # 订阅默认主题
            client.subscribe(f"tylink/{self.device_id}/#", qos=1)
        else:
            self.connected = False
            error_msg = mqtt.connack_string(rc)
            self.last_error = error_msg
            self.logger.error(f"MQTT连接失败: {error_msg}")

    def _on_disconnect(self, client, userdata, rc):
        """MQTT断开回调"""
        self.connected = False
        if rc != 0:
            self.last_error = f"意外断开: {mqtt.error_string(rc)}"
            self.logger.warning(f"MQTT连接断开: {self.last_error}")
            
    def _on_message(self, client, userdata, msg):
        """MQTT消息回调"""
        self.logger.debug(f"收到消息 [主题:{msg.topic}]")
        for callback in self.message_callbacks:
            try:
                callback(msg.topic, msg.payload.decode())
            except Exception as e:
                self.logger.error(f"消息回调处理失败: {e}")

    def add_message_callback(self, callback: Callable[[str, str], None]):
        """添加消息回调函数"""
        self.message_callbacks.append(callback)

    def connect(self, max_retries: int = 3, retry_interval: float = 5.0) -> bool:
        """
        连接到涂鸦MQTT服务器
        :param max_retries: 最大重试次数
        :param retry_interval: 重试间隔(秒)
        :return: 是否连接成功
        """
        for attempt in range(1, max_retries + 1):
            try:
                # 生成认证参数
                username, password = self._generate_auth_params()
                
                # 创建客户端
                self.client = mqtt.Client(
                    client_id=f"tuyalink_{self.device_id}",
                    protocol=mqtt.MQTTv311,
                    transport="tcp"
                )
                
                # 设置回调
                self.client.on_connect = self._on_connect
                self.client.on_disconnect = self._on_disconnect
                self.client.on_message = self._on_message
                
                # 配置TLS
                self.client.tls_set(
                    ca_certs=self.ca_cert,
                    cert_reqs=mqtt.ssl.CERT_REQUIRED,
                    tls_version=mqtt.ssl.PROTOCOL_TLSv1_2
                )
                self.client.tls_insecure_set(False)
                
                # 设置认证
                self.client.username_pw_set(username, password)
                
                # 连接服务器
                self.logger.info(f"尝试连接MQTT服务器(第{attempt}次)...")
                self.client.connect("m1.tuyacn.com", 8883, 60)
                self.client.loop_start()
                
                # 等待连接完成
                start_time = time.time()
                while not self.connected and (time.time() - start_time) < 10:
                    time.sleep(0.1)
                
                if self.connected:
                    return True
                    
            except Exception as e:
                self.last_error = str(e)
                self.logger.error(f"连接尝试{attempt}失败: {e}")
                
            if attempt < max_retries:
                time.sleep(retry_interval)
        
        return False

    def publish_data(self, data):
        """
        发布单词学习数据到涂鸦云
        :param data: 包含学习统计信息的字典
        :return: 是否发布成功
        """
        if not self.connected:
            self.logger.warning("发布失败: MQTT未连接")
            return False
            
        try:
            payload = {
                "msgId": f"word_data_{int(time.time())}",
                "time": int(time.time() * 1000),  # 毫秒级时间戳
                "data": {
                    "total_words": data.get("total_words", 0)
                    # "mastered_words": data.get("mastered_words", 0),
                    # "today_studied": data.get("today_studied", 0)
                }
            }
            
            topic = f"tylink/{self.device_id}/thing/property/report"
            result = self.client.publish(topic, json.dumps(payload), qos=1)
            
            if result.rc != mqtt.MQTT_ERR_SUCCESS:
                self.logger.error(f"发布失败: {mqtt.error_string(result.rc)}")
                return False
                
            self.logger.info("数据已发布到涂鸦云")
            return True
            
        except Exception as e:
            self.last_error = str(e)
            self.logger.error(f"发布消息异常: {e}")
            return False

    def publish_attention(self, attention_value: float) -> bool:
        """
        发布专注度数据到涂鸦云
        :param attention_value: 专注度值(0-100)
        :return: 是否发布成功
        """
        if not self.connected:
            # 尝试重新连接
            self.logger.warning("MQTT未连接，尝试重新连接...")
            if not self.connect():
                self.logger.error("重新连接失败，无法发布数据")
                return False
            
        try:
            current_time = str(int(time.time())) + "000"
            
            # 构建payload字符串（使用字符串拼接方式）
            payload = "{"
            payload += "\"msgId\":\"attention_data_" + current_time + "\","
            payload += "\"time\":\"" + current_time + "000\","

            payload += "\"data\":{"
            payload += "\"attention_value\":{"
            payload += "\"value\":\"" + str(round(attention_value, 2)) + "\","
            payload += "\"time\":\"" + current_time + "000\""
            payload += "}"
            payload += "}"
            payload += "}"

            topic = f"tylink/{self.device_id}/thing/property/report"
            result = self.client.publish(topic, payload, qos=1)
            
            if result.rc != mqtt.MQTT_ERR_SUCCESS:
                self.logger.error(f"发布失败: {mqtt.error_string(result.rc)}")
                # 发布失败后断开连接，下次发布时会尝试重连
                self.disconnect()
                return False
                
            self.logger.info(f"专注度数据已发布: {attention_value:.2f}")
            return True
            
        except Exception as e:
            self.last_error = str(e)
            self.logger.error(f"发布消息异常: {e}")
            # 发生异常后断开连接，下次发布时会尝试重连
            self.disconnect()
            return False

    def disconnect(self):
        """断开MQTT连接"""
        if self.client:
            try:
                self.client.loop_stop()
                self.client.disconnect()
                self.connected = False
                self.logger.info("MQTT连接已断开")
            except Exception as e:
                self.logger.error(f"断开连接时出错: {e}")
                
    def __del__(self):
        """析构函数确保资源清理"""
        self.disconnect()
        try:
            if self.ca_cert and os.path.exists(self.ca_cert):
                os.unlink(self.ca_cert)
        except:
            pass

# class EssayGenerator:
#     """智能短文生成器（平衡速度与多样性）"""
    
#     def __init__(self, llm_model=None):
#         self.llm = llm_model
#         # 多样化主题库
#         self.themes = [
#             "科技与未来", "日常生活", "旅行见闻", "校园故事", 
#             "奇幻冒险", "环境保护", "健康生活", "历史文化"
#         ]
#         # 多风格模板
#         self.templates = [
#             "用{words}写个{theme}相关的小段落，要求：\n"
#             "1. 包含所有给定单词\n2. 开头写'Here is your essay:'\n"
#             "3. 50-150词即可\n4. 自然流畅",
            
#             "请创作一个关于{theme}的英文小短文，必须使用这些单词：{words}\n"
#             "开头标注：'Here is your essay:'\n"
#             "长度不限，确保包含所有单词即可",
            
#             "任务：用{words}编写{theme}主题的微型故事\n"
#             "要求：\n"
#             "- 开头标明'Here is your essay:'\n"
#             "- 包含全部单词\n"
#             "- 保持基本逻辑通顺"
#         ]

#     def generate_essay(self, words: List[str]) -> str:
#         """智能生成短文（平衡速度与质量）"""
#         if not self.llm or not words:
#             return self._fallback_essay(words)

#         # 随机选择主题和模板
#         theme = random.choice(self.themes)
#         template = random.choice(self.templates)
        
#         # 构建灵活提示词
#         prompt = template.format(
#             words=', '.join(words),
#             theme=theme
#         ) + "\n（不必严格优化，首先生成可用内容即可）"

#         try:
#             # 快速生成（不调整模型参数）
#             start_time = time.time()
#             raw_output = self.llm.raw_generate(prompt) or ""
            
#             # 基础格式处理
#             if "Here is your essay:" not in raw_output:
#                 raw_output = f"Here is your essay:\n{raw_output}"
                
#             # 提取有效内容（保留原始生成结果）
#             essay = raw_output.split("Here is your essay:")[-1].strip()
#             print(f"生成耗时：{time.time()-start_time:.2f}s")
#             return essay
            
#         except Exception as e:
#             print(f"生成异常：{e}")
#             return self._fallback_essay(words)
    
#     def _fallback_essay(self, words: List[str]) -> str:
#         """保底生成方案"""
#         return (
#             f"Here is your essay:\n"
#             f"This passage includes: {', '.join(words)}.\n"
#             f"Let me tell you a quick story using these words..."
#         )
    
class WordReciteApp:
    def __init__(self, root):
        self.root = root
        self.root.title("专芯链词")
        self.root.resizable(0, 0)

        # 7寸屏适配设置
        self.width = 1024  
        self.height = 600  
        self.root.geometry(f"{self.width}x{self.height}")
        self.root.attributes('-fullscreen', True)  # 新增全屏
        self.root.bind('<Escape>', lambda e: self.root.attributes('-fullscreen', not self.root.attributes('-fullscreen')))
        
        # 按比例调整字体大小
        # self.font_scale = 0.8  # 字体缩放系数

        self.scale_x = self.width / 1042
        self.scale_y = self.height / 600

        self.bg_color = '#F7F1E5'      # 米白色背景
        self.text_color = '#5a4a3a'    # 主文字色（深棕）
        self.title_color = '#3a2a16'   # 标题文字色（更深棕）
        self.button_bg = '#8b7355'     # 按钮背景（咖啡色）
        self.button_fg = 'white'       # 按钮文字色
        self.input_bg = 'white'        # 输入框背景
        self.border_color = '#a58c6c'  # 边框色
        self.widget_bg = '#F9F5EB'  # 比背景亮5%的衍生色
        self.border_color = '#D9C7A7'  # 自然阴影色

        # 涂鸦云MQTT配置
        self.TUYA_DEVICE_ID = "26e220d7c70b49a103ymkd"     # 涂鸦云设备ID
        self.TUYA_SECRET_KEY = "7WBY9FoWLQYEFtW1"  # 涂鸦云Secret Key
        
        # 初始化MQTT客户端
        self.mqtt_client = TuyaMQTTManager(
            self.TUYA_DEVICE_ID,
            self.TUYA_SECRET_KEY
        )
        
        try:
            self.mqtt_client.connect()
        except Exception as e:
            print(f"MQTT初始化失败: {e}")

        # 脑电监测初始化
        self.eeg_monitor = EEGMonitor(
            device_id=self.TUYA_DEVICE_ID,  # 使用同一个涂鸦云账号
            device_secret=self.TUYA_SECRET_KEY
        )

        # 启动脑电监测线程
        self.start_eeg_monitoring()

        # 启动脑机数据定时上传
        self.eeg_upload_interval = 1000  # 1秒 = 1000毫秒
        self.start_eeg_data_upload()

        # 学习池和批次管理
        self.POOL_SIZE = 20           # 学习池大小
        self.BATCH_SIZE = 5          # 每批次单词数量
        self.current_pool = []        # 当前学习池
        self.current_batch = []       # 当前批次
        self.word_history = []        # 单词学习历史
        self.mastered_words = set()   # 已掌握的单词集合
        
        # 记录上一个单词ID，避免连续重复
        self.last_word_id = None      

        # 状态标志
        self.checked = False          # 是否已检查拼写
        self.spell_boxes = []         # 提前声明属性
        
        # 初始化UI变量
        self.word = tk.StringVar()
        self.en = tk.StringVar()
        self.us = tk.StringVar()
        self.meaning = tk.StringVar()
        self.score = tk.StringVar()
        self.learned_str_count = tk.StringVar()
        self.answer = tk.StringVar()
        self.spell = tk.StringVar()
        self.batch_progress = tk.StringVar()
        
        # 专注度状态变量
        # self.attention_text = tk.StringVar()
        # self.attention_text.set("专注度: 等待连接...")

        # 统计变量
        self.today_count = 0          # 今日背诵单词量
        self.week_counts = deque(maxlen=7)  # 最近7天背诵量
        self.last_study_date = None   # 上次学习日期
        
        # 整合统计数据的属性
        self.statistics_data = {
            "total_words": 0,          # 总单词数
            "mastered_words": 0,       # 已掌握单词数
            "remaining_words": 0,      # 待背单词数
            "today_mastered": 0        # 今日已掌握单词数
        }

        # 初始化UI
        self.init_ui()

        # 初始化TTS
        self.tts = OnlineTTS()
        
        # 加载数据（在UI初始化之后）
        self.load_data()

        # # 初始化LLM模型和短文生成器
        # try:
        #     self.llm = RKLLM("./deepseek-1.5b-w8a8-rk3588.rkllm")
        #     self.essay_generator = EssayGenerator(self.llm)  # 关键修改点
        # except Exception as e:
        #     print(f"LLM初始化失败: {e}")
        #     self.llm = None
        #     self.essay_generator = EssayGenerator(None)
        #     messagebox.showwarning("警告", "LLM初始化失败，短文生成功能受限")
        
        # 绑定关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)


        # self.mqtt_status = tk.StringVar()
        # self.mqtt_status.set("MQTT: 连接中")
        # self.status_label = tk.Label(root, textvariable=self.mqtt_status, bg='#fdf2eb', fg='orange', font=("微软雅黑", 12))
        # self.status_label.place(x=850, y=10)

        # self.connection_label = tk.Label(
        #     root,
        #     text="脑机: 检测中...",
        #     font=("微软雅黑", 12),
        #     bg=self.bg_color
        # )
        # self.connection_label.place(x=850, y=40)

        # MQTT连接状态指示器
        self.mqtt_status = tk.StringVar()
        self.mqtt_status.set("MQTT: 连接中")
        self.status_label = tk.Label(
            self.root,
            textvariable=self.mqtt_status,
            bg=self.bg_color,
            fg='#5a4a3a',
            font=("微软雅黑", 10)
        )
        self.status_label.place(x=850*self.scale_x, y=10*self.scale_y)

        # 显示脑机连接状态的标签
        self.connection_label = tk.Label(
            self.root,
            text="脑机: 检测中...",
            bg=self.bg_color,
            fg='#5a4a3a',
            font=("微软雅黑", 10)
        )
        self.connection_label.place(x=850*self.scale_x, y=40*self.scale_y)
        
        # 每2秒检测一次
        self.check_connection()

        # 定期检查MQTT连接状态
        self.check_mqtt_connection()
#####

    def check_mqtt_connection(self):
        """定期检查MQTT连接状态"""
        if self.mqtt_client.connected:
            self.mqtt_status.set("MQTT: 已连接")
            self.status_label.config(fg="green")
        else:
            self.mqtt_status.set(f"MQTT: 已断开 ({self.mqtt_client.last_error})")
            self.status_label.config(fg="red")
            
            # 尝试重新连接
            try:
                if not self.mqtt_client.connect():
                    self.logger.warning("MQTT重连失败，将重试")
            except Exception as e:
                self.logger.error(f"MQTT重连异常: {e}")
                
        self.root.after(5000, self.check_mqtt_connection)  # 每5秒检查一次

    def toggle_fullscreen(self, event=None):
        """全屏切换函数"""
        self.fullscreen = not self.fullscreen
        self.root.attributes('-fullscreen', self.fullscreen)
        
        # 保持窗口比例（可选）
        if not self.fullscreen:
            self.root.geometry(f"{self.width}x{self.height}")

    def load_data(self):
        # 确保数据目录存在
        if not os.path.exists("./data"):
            os.makedirs("./data")
            messagebox.showerror("错误", "请确保data目录存在并包含必要的数据文件")
            return
        
        try:
            # 加载索引文件
            self.cos_index = np.load("./data/cos_index.npy") if os.path.exists("./data/cos_index.npy") else np.array([])
            self.jaro_index = np.load("./data/jaro_index.npy") if os.path.exists("./data/jaro_index.npy") else np.array([])
            
            # 连接数据库
            self.conn = sqlite3.connect("./data/data.db")
            self.c = self.conn.cursor()
            
            # 确保表结构正确
            self.ensure_table_structure()
            
            # 获取总单词数和已掌握单词数
            self.c.execute("SELECT COUNT(*) FROM words")
            self.word_count = self.c.fetchone()[0]
            self.c.execute("SELECT COUNT(*) FROM words WHERE count >= 3")
            self.learned_word_count = self.c.fetchone()[0]
            
            # 获取当前进度
            self.c.execute("SELECT id FROM process")
            result = self.c.fetchone()
            self.process_count = result[0] if result else 0
            
            # 加载已掌握单词
            self.c.execute("SELECT id FROM words WHERE count >= 3")
            self.mastered_words = set(row[0] for row in self.c.fetchall())
            
            # 加载统计信息
            self.load_statistics()
            
            # 初始化学习池
            self.initialize_pool()
            
            # 加载当前单词
            self.load_current_word()
            
            # 初始播放（确保单词已加载）
            self.safe_speak(self.word.get())
            
            # 初始化统计数据
            self.update_statistics_data()  # 首次加载时更新统计值

        except Exception as e:
            messagebox.showerror("数据错误", f"加载数据失败: {str(e)}")
            raise

    def ensure_table_structure(self):
        """确保数据库表结构正确"""
        try:
            # 创建表（如果不存在）
            self.c.execute('''
                CREATE TABLE IF NOT EXISTS words (
                    id INTEGER PRIMARY KEY,
                    word TEXT UNIQUE,
                    en TEXT,
                    us TEXT,
                    meaning TEXT,
                    count INTEGER DEFAULT 0,
                    last_updated TEXT
                )
            ''')
            
            # 检查表是否有last_updated列
            self.c.execute("PRAGMA table_info(words)")
            columns = [row[1] for row in self.c.fetchall()]
            
            if 'last_updated' not in columns:
                # 添加last_updated列
                self.c.execute("ALTER TABLE words ADD COLUMN last_updated TEXT")
                # 为现有记录设置默认值
                self.c.execute("UPDATE words SET last_updated = CURRENT_TIMESTAMP WHERE last_updated IS NULL")
                self.conn.commit()
                
            # 创建其他表
            self.c.execute('''
                CREATE TABLE IF NOT EXISTS process (
                    id INTEGER DEFAULT 0
                )
            ''')
            self.c.execute('''
                CREATE TABLE IF NOT EXISTS statistics (
                    date TEXT PRIMARY KEY,
                    count INTEGER
                )
            ''')
            self.conn.commit()
            
        except Exception as e:
            print(f"确保表结构时出错: {e}")
            raise



    def initialize_pool(self):
        """初始化学习池：20个未掌握的单词"""
        self.c.execute("""
            SELECT id FROM words 
            WHERE count < 3 
            ORDER BY RANDOM()
            LIMIT ?
        """, (self.POOL_SIZE,))
        
        self.current_pool = [row[0] for row in self.c.fetchall()]
        print(f"初始化学习池: {self.current_pool}")

    def get_next_word(self):
        """从学习池随机获取一个未掌握的单词（排除上一个单词）"""
        # 确保学习池中没有已掌握的单词，并排除上一个单词
        candidates = [
            w for w in self.current_pool 
            if w not in self.mastered_words and w != self.last_word_id
        ]
        
        if not candidates:
            # 若候选集为空（只剩下上一个单词），允许使用上一个单词（避免死锁）
            candidates = [w for w in self.current_pool if w not in self.mastered_words]
            
        if not candidates:  # 如果还是没有单词
            messagebox.showinfo("提示", "所有单词已掌握！")
            return None
        
        # 随机选择一个单词
        next_word_id = random.choice(candidates)
        return next_word_id

    def update_pool(self):
        """更新学习池：补充新单词"""
        # 首先移除已掌握的单词
        self.current_pool = [w for w in self.current_pool if w not in self.mastered_words]
        
        # 计算需要补充的单词数量
        needed = self.POOL_SIZE - len(self.current_pool)
        if needed > 0:
            # 获取新的未掌握单词（排除已在学习池中的单词）
            placeholders = ','.join(['?'] * len(self.current_pool)) if self.current_pool else 'NULL'
            query = f"""
                SELECT id FROM words 
                WHERE count < 3 
                AND id NOT IN ({placeholders})
                ORDER BY RANDOM()
                LIMIT ?
            """
            params = self.current_pool + [needed] if self.current_pool else [needed]
            
            self.c.execute(query, params)
            new_words = [row[0] for row in self.c.fetchall()]
            self.current_pool.extend(new_words)
            print(f"补充了 {len(new_words)} 个新单词到学习池")

    def load_current_word(self):
        """加载当前单词"""
        self.c.execute("SELECT * FROM words WHERE id = ?", (self.process_count,))
        result = self.c.fetchone()
        
        self.answer.set('')  # 初始化为空
        if hasattr(self, 'label_word') and self.label_word:  # 双重检查
            self.label_word.config(fg=self.text_color)  # 使用预设的文字颜色

        self.max_input_length = len(self.word.get())  # 更新最大长度限制
        self.main_input_box.delete(0, 'end')  # 清空输入

        if not result:
            # 如果当前ID的单词不存在，获取第一个单词
            self.c.execute("SELECT * FROM words ORDER BY id ASC LIMIT 1")
            result = self.c.fetchone()
            if not result:
                messagebox.showerror("错误", "数据库中没有单词！")
                return
                
            self.process_count = result[0]
            messagebox.showinfo("提示", f"ID为{self.process_count}的单词不存在，已加载第一个单词")
        
        # 更新Tkinter变量
        self.word.set(result[1])
        self.en.set(result[2])
        self.us.set(result[3])
        self.meaning.set(result[4])
        self.this_count = result[5]
        self.score.set(f"{self.this_count}/3")
        self.learned_str_count.set(f"{self.learned_word_count}/{self.word_count}")
        self.answer.set('')  # 初始时不显示任何内容
        self.spell.set('')   # 初始时不显示任何内容
        self.batch_progress.set(f"已背: {len(self.current_batch)}/{self.BATCH_SIZE}")
        
        # 更新拼写输入框
        self.update_spelling_boxes()
        
        # 清空主输入框
        if hasattr(self, 'main_input_box'):
            self.main_input_box.delete(0, 'end')
        
        # 加载新单词后自动播放语音
        self.safe_speak(self.word.get())

    def init_ui(self):
        # 背景图片
        self.setup_background()
        
        # 图标
        self.setup_icon()

        #拼写框
        self.spell_frame = tk.Frame(self.root, bg='#fdf2eb')
        self.spell_frame.place(x=150, y=260)
        
        # 标签和输入框
        self.create_labels()
        self.create_input_boxes()
        self.create_buttons()
        
        # 单词变化时更新拼写输入框
        self.word.trace_add('write', lambda *args: self.update_spelling_boxes())
        
        # 键盘绑定
        self.root.bind('<Key>', self.key_press)

    def setup_background(self):
        # 主画布背景

        
        try:
            # 使用您提供的背景图（确保图片路径正确）
            bg_image = Image.open('./assets/back.jpg')
            # 精确匹配窗口尺寸
            bg_image = bg_image.resize((self.width, self.height), Image.LANCZOS)
            self.bg_photo = ImageTk.PhotoImage(bg_image)
            
            # 创建背景标签（覆盖整个窗口）
            bg_label = tk.Label(
                self.root, 
                image=self.bg_photo,
                borderwidth=0  # 去除边框
            )
            bg_label.place(x=0, y=0, relwidth=1, relheight=1)
            bg_label.lower()  # 确保背景在最底层
            
        except Exception as e:
            print(f"加载背景图失败: {e}")
            # 回退到纯色背景
            self.root.config(bg=self.bg_color)

    def setup_icon(self):
        try:
            icon = Image.open('./assets/logo.jpg')
            icon = icon.resize((100, 100))
            self.icon = ImageTk.PhotoImage(icon)
            self.root.iconphoto(False, self.icon)
        except:
            pass

    def create_labels(self):
        # 定义样式（保持原有结构，仅优化颜色）

        title_style = {
            'bg': self.bg_color,
            'fg': '#5A3A28',  # 深棕色标题
            'font': ("微软雅黑", 20, "bold") 
        }
        
        content_style = {
            'bg': self.bg_color,
            'fg': '#4A3C29',  # 稍浅内容文字
            'font': ("微软雅黑", 18 )
        }
        
        input_style = {
            'bg': self.bg_color,
            'fg': '#7A5C3C',  # 浅棕色提示
            'font': ("微软雅黑", 16 )
        }
        
        labels_info = [
            ('掌握程度：', 30*self.scale_x, 90*self.scale_y, title_style),
            ('学习进度：', 200*self.scale_x, 90*self.scale_y, title_style),
            ('中文释义：', 30*self.scale_x, 130*self.scale_y, content_style),
            ('美式音标：', 30*self.scale_x, 170*self.scale_y, content_style),
            ('英式音标：', 30*self.scale_x, 210*self.scale_y, content_style),
            ('单词拼写：', 30*self.scale_x, 260*self.scale_y, input_style),
            ('拼写情况：', 30*self.scale_x, 310*self.scale_y, input_style),  
            ('这里输入：', 30*self.scale_x, 360*self.scale_y, input_style)
        ]
        
        for text, x, y, style in labels_info:
            tk.Label(self.root, text=text, **style).place(x=x, y=y)

        # 动态标签（保留所有变量绑定，原拼写情况动态展示相关的去掉）
        tk.Label(
            self.root,
            textvariable=self.score,
            bg=self.bg_color,
            fg='#2A7F3F',  # 绿色进度
            font=("微软雅黑",  20, "bold")
        ).place(x=150*self.scale_x, y=90*self.scale_y)
        
        tk.Label(
            self.root,
            textvariable=self.learned_str_count,
            bg=self.bg_color,
            fg='#2A7F3F',
            font=("微软雅黑",  20, "bold")
        ).place(x=320*self.scale_x, y=90*self.scale_y)
        
        # 批次进度标签（重点保留！）
        tk.Label(
            self.root,
            textvariable=self.batch_progress,
            bg=self.bg_color,
            fg='#5A3A28',  # 与标题同色
            font=("微软雅黑",  18, "bold")  # 加粗显示
        ).place(x=700*self.scale_x, y=90*self.scale_y)  # 保持右上角位置不变

        # 其他变量标签
        var_labels = [
            (self.meaning, 150*self.scale_x, 130*self.scale_y),
            (self.us, 150*self.scale_x, 170*self.scale_y),
            (self.en, 150*self.scale_x, 210*self.scale_y),
            (self.spell, 30*self.scale_x, 310*self.scale_y),
            (self.answer, 150*self.scale_x, 310*self.scale_y)
        ]
        
        for var, x, y in var_labels:
            tk.Label(
                self.root,
                textvariable=var,
                bg=self.bg_color,
                fg=self.text_color,
                font=("微软雅黑",  18)
            ).place(x=x, y=y)

        # 拼写检查标签
        self.label_spell = tk.Label(
            self.root, 
            textvariable=self.spell,
            bg=self.bg_color,
            fg=self.text_color,
            font=("微软雅黑",  18 )
        )
        self.label_spell.place(x=30*self.scale_x, y=310*self.scale_y)
        
        self.label_word = tk.Label(
            self.root, 
            textvariable=self.answer,
            bg=self.bg_color,
            fg=self.text_color,
            font=("微软雅黑",  18)
        )
        self.label_word.place(x=150*self.scale_x, y=310*self.scale_y)

    # def create_input_boxes(self):
    #     # 主输入框
    #     self.main_input_box = tk.Entry(
    #         self.root,
    #         width=20,
    #         bg=self.input_bg,
    #         fg=self.text_color,
    #         font=("微软雅黑", 20),
    #         highlightthickness=1,
    #         highlightbackground=self.border_color,
    #         insertbackground=self.text_color  # 光标颜色
    #     )
    #     self.main_input_box.place(x=150, y=360)
    #     self.main_input_box.bind('<KeyRelease>', self.on_entry_change)
    #     self.main_input_box.bind('<BackSpace>', self.on_entry_change)
    #     self.main_input_box.focus_set()

    #     # 跳转输入框
    #     self.jump_input_box = tk.Entry(
    #         self.root,
    #         width=15,
    #         bg=self.input_bg,
    #         fg=self.text_color,
    #         font=("微软雅黑", 20),
    #         highlightthickness=1,
    #         highlightbackground=self.border_color
    #     )
    #     self.jump_input_box.place(x=650, y=360)

    #     # 拼写框容器（位置保持不变）
    #     self.spell_frame = tk.Frame(self.root, bg=self.bg_color)
    #     self.spell_frame.place(x=150, y=260)

    def create_input_boxes(self):
        # 主输入框（优化视觉效果）
        self.main_input_box = tk.Entry(
            self.root,
            width=20,
            bg='#FFFDF9',          # 极浅米白背景
            fg='#3A2E1E',          # 深棕色文字
            font=("微软雅黑", 20),
            highlightthickness=1,
            highlightbackground='#C0A080',  # 浅咖啡色边框
            insertbackground='#5A3A28',     # 光标颜色
            relief='flat',
            validate="key",
            validatecommand=(self.root.register(self.validate_input), '%P')
        )
        self.main_input_box.place(x=150*self.scale_x, y=360*self.scale_y)
        self.main_input_box.bind('<KeyRelease>', self.on_entry_change)
        
        # 跳转输入框
        self.jump_input_box = tk.Entry(
            self.root,
            width=15,
            bg='#FFFDF9',
            fg='#3A2E1E',
            font=("微软雅黑", 20),
            highlightthickness=1,
            highlightbackground='#C0A080'
        )
        self.jump_input_box.place(x=650*self.scale_x, y=360*self.scale_y)

        # 拼写框容器（透明背景）
        self.spell_frame = tk.Frame(
            self.root, 
            bg=self.bg_color,
            borderwidth=0
        )
        self.spell_frame.place(x=150*self.scale_x, y=260*self.scale_y)

    def create_buttons(self):
        buttons = [
            ('下一个', 500*self.scale_x, 415*self.scale_y, self.on_click_next),
            ('上一个', 350*self.scale_x, 415*self.scale_y, self.on_click_last),
            ('检查', 200*self.scale_x, 415*self.scale_y, self.on_click_check),
            ('我已掌握', 50*self.scale_x, 415*self.scale_y, self.on_click_ok),
            ('形近词跳转', 650*self.scale_x, 415*self.scale_y, self.on_click_jump_jaro),
            ('近义词跳转', 800*self.scale_x, 415*self.scale_y, self.on_click_jump_cos),
            ('学习统计', 650*self.scale_x, 500*self.scale_y, self.show_statistics),
            ('同步数据', 800*self.scale_x, 500*self.scale_y, self.publish_statistics)
        ]
        
        for text, x, y, command in buttons:
            btn = tk.Button(
                self.root,
                text=text,
                width=10 if text not in [ "形近词跳转", "近义词跳转", "学习统计", "同步数据"] else (6 if text == "跳转到：" else 10),
                height=2,
                bg=self.button_bg,
                fg=self.button_fg,
                font=("微软雅黑", 12),
                relief='flat',
                borderwidth=0,
                activebackground='#a58c6c',
                activeforeground='white',
                command=command
            )
            btn.place(x=x, y=y)

        # # 提示标签（保持原位置）
        # tk.Label(
        #     self.root,
        #     text='可以按回车键检查，按↓键或者→键到下一个单词，按↑键或者←到上一个单词',
        #     bg=self.bg_color,
        #     fg='#666666',  # 灰色提示文字
        #     font=("微软雅黑", 14)
        # ).place(x=50, y=465)

    def safe_speak(self, text):
        try:
            if text:  # 确保有文本内容才播放
                self.tts.speak(text)
        except Exception as e:
            print(f"播放语音出错: {e}")
            messagebox.showerror("错误", f"无法播放语音: {str(e)}")

    def on_close(self):
        """关闭应用时的清理工作"""
        # 保存当前进度
        self.publish_statistics()  # 关闭时同步数据

        # 1. 先停止语音（最重要）
        if hasattr(self, 'tts'):
            self.tts.cleanup()
        
        # 2. 停止其他服务
        if hasattr(self, 'eeg_monitor'):
            self.eeg_monitor.stop()
        
        # 3. 关闭MQTT
        if hasattr(self, 'mqtt_client'):
            self.mqtt_client.disconnect()

        try:
            self.c.execute("DELETE FROM process")
            self.c.execute("INSERT INTO process VALUES (?)", (self.process_count,))
            self.conn.commit()
        except Exception as e:
            print(f"保存进度失败: {e}")          
            
        # 关闭数据库连接
        if hasattr(self, 'conn') and self.conn:
            self.conn.close()

        # 取消脑机数据上传定时器
        if hasattr(self, 'eeg_upload_timer'):
            self.root.after_cancel(self.eeg_upload_timer)           

        # 清理LLM资源
        if hasattr(self, 'llm') and self.llm is not None:
            try:
                self.llm.release()  # 新增资源释放
            except Exception as e:
                print(f"释放LLM资源失败: {e}")
            
        # 关闭窗口
        self.root.destroy()
        os._exit(0)

    def update_spelling_boxes(self):
        """延迟更新拼写框，避免频繁刷新"""
        if hasattr(self, '_spell_update_pending'):
            self.root.after_cancel(self._spell_update_pending)
        
        # 延迟100ms执行实际更新
        self._spell_update_pending = self.root.after(100, self._real_update_spelling_boxes)

    def _real_update_spelling_boxes(self):
        for widget in self.spell_frame.winfo_children():
            widget.destroy()
        
        word = self.word.get()
        self.max_input_length = len(word)
        self.spell_boxes = []
        
        for i in range(len(word)):
            box = tk.Entry(
                self.spell_frame,
                width=2,
                bg=self.input_bg,
                fg=self.text_color,
                font=("Arial", 18),  # 等宽字体
                justify='center',
                highlightthickness=1,
                highlightbackground=self.border_color,
                insertbackground=self.text_color
            )
            box.grid(row=0, column=i, padx=2)
            box.bind('<Key>', lambda e, idx=i: self.on_letter_typing(e, idx))
            self.spell_boxes.append(box)

    def on_letter_typing(self, event, index):
        """处理字母输入"""
        current_box = self.spell_boxes[index]
        text = current_box.get()
        
        # 如果输入了字母，自动跳到下一个框
        if text and len(text) > 0 and index < len(self.spell_boxes) - 1:
            self.spell_boxes[index + 1].focus_set()
            
        # 如果按了退格键，跳到前一个框
        if event.keysym == 'BackSpace' and index > 0 and not text:
            self.spell_boxes[index - 1].focus_set()

    def on_entry_change(self, event):
        """同步输入到拼写格子 - 确保第一个格子不被跳过"""
        input_text = self.main_input_box.get()
        
        # 同步到每个格子
        for i in range(len(self.spell_boxes)):
            if i < len(input_text):
                # 只取单个字母
                self.spell_boxes[i].delete(0, 'end')
                self.spell_boxes[i].insert(0, input_text[i])
            else:
                self.spell_boxes[i].delete(0, 'end')

    def create_input_boxes(self):
        """创建输入框 - 添加严格验证"""
        # 主输入框
        self.main_input_box = tk.Entry(
            self.root,
            width=20,
            bg=self.bg_color,
            font=("微软雅黑", 20),
            validate="key",
            validatecommand=(self.root.register(self.validate_input), '%P')
        )
        self.main_input_box.place(x=150*self.scale_x, y=360*self.scale_y)
        self.main_input_box.bind('<KeyRelease>', self.on_entry_change)
        
        # 拼写框容器（确保在最前面创建）
        self.spell_frame = tk.Frame(self.root, bg=self.bg_color)
        self.spell_frame.place(x=150*self.scale_x, y=260*self.scale_y)  # 调整到合适位置

    def validate_input(self, proposed_text):
        """输入验证 - 确保不超过格子数量"""
        max_len = getattr(self, 'max_input_length', 0)
        return len(proposed_text) <= max_len

    def key_press(self, event):
        """键盘事件处理"""
        if event.keysym == 'Return':  # 回车键
            if not self.checked:  # 第一次按回车，检查拼写
                self.on_click_check()
            else:  # 已经检查过了，按回车跳到下一个
                self.on_click_next()
                self.checked = False  # 重置检查状态
        elif event.keysym == 'Down' or event.keysym == 'Right':  # 下箭头或右箭头
            self.on_click_next()
        elif event.keysym == 'Up' or event.keysym == 'Left':  # 上箭头或左箭头
            self.on_click_last()

    def on_click_check(self):
        """检查拼写按钮点击事件"""
        if self.checked:  # 如果已经检查过了，直接跳到下一个
            self.on_click_next()
            return
            
        user_input = self.main_input_box.get().strip().lower()
        correct_word = self.word.get().lower()
        
        # 只在检查时显示正确拼写
        self.answer.set(correct_word)  # 显示正确答案
        
        if user_input == correct_word:
            # 拼写正确 - 绿色显示
            self.label_word.config(fg='green')
            # 更新掌握状态
            self.this_count += 1
            self.c.execute("""
                UPDATE words 
                SET count = ?, last_updated = CURRENT_TIMESTAMP 
                WHERE id = ?
            """, (self.this_count, self.process_count))
            self.conn.commit()
            
            if self.this_count >= 3:
                self.mastered_words.add(self.process_count)
                self.learned_word_count += 1
                self.update_statistics_data()
                self.update_pool()
                
                # 新增：上传已掌握的单词
                self.upload_mastered_word()

                if self.process_count not in self.current_batch:
                    self.current_batch.append(self.process_count)
                    
                if len(self.current_batch) >= self.BATCH_SIZE:
                    self._handle_batch_completion()  
                    self.current_batch = []
                    
            self.score.set(f"{self.this_count}/3")
            self.learned_str_count.set(f"{self.learned_word_count}/{self.word_count}")
        else:
            # 拼写错误 - 红色显示
            self.label_word.config(fg='red')
            
        self.checked = True

    def on_click_ok(self):
        """我已掌握按钮点击事件"""
        # 如果当前单词掌握程度小于3，直接设为3
        if self.this_count < 3:
            self.c.execute("""
                UPDATE words 
                SET count = 3, last_updated = CURRENT_TIMESTAMP 
                WHERE id = ?
            """, (self.process_count,))
            self.conn.commit()
            
            # 更新界面显示
            self.this_count = 3
            self.score.set(f"{self.this_count}/3")
            
            # 如果单词不在已掌握集合中，添加进去
            if self.process_count not in self.mastered_words:
                self.mastered_words.add(self.process_count)
                self.learned_word_count += 1
                self.learned_str_count.set(f"{self.learned_word_count}/{self.word_count}")
                
                # 上传已掌握的单词
                self.upload_mastered_word()

                # 更新统计信息
                self.update_statistics()
                self.update_statistics_data()
                
                # 更新学习池
                self.update_pool()
                
                # 添加到当前批次
                if self.process_count not in self.current_batch:
                    self.current_batch.append(self.process_count)
                    
                # 检查批次是否完成
                if len(self.current_batch) >= self.BATCH_SIZE:
                    self._handle_batch_completion()  
                    self.current_batch = []
        
        # 移动到下一个单词
        self.on_click_next()

    def on_click_next(self):
        """下一个单词按钮点击事件"""
        next_word_id = self.get_next_word()
        if next_word_id is not None:
            self.last_word_id = self.process_count  # 记录当前单词为上一个
            self.process_count = next_word_id
            self.load_current_word()  # 这会清空显示并播放新单词的语音
            self.checked = False  # 重置检查状态
            self.label_word.config(fg='black')  # 重置文字颜色
        else:
            messagebox.showinfo("提示", "所有单词已掌握！")

    def on_click_last(self):
        """上一个单词按钮点击事件"""
        if len(self.word_history) > 0:
            self.process_count = self.word_history.pop()
            self.load_current_word()  # 加载历史单词并播放语音
            self.checked = False  # 重置检查状态
        else:
            messagebox.showinfo("提示", "没有上一个单词记录！")

    def on_click_jump_jaro(self):
        try:
            if self.process_count < len(self.jaro_index):
                target_id = int(self.jaro_index[self.process_count])
                self.process_count = target_id
                self.c.execute("UPDATE process SET id = ?", (self.process_count,))
                self.conn.commit()
                self.load_current_word()
        except Exception as e:
            messagebox.showinfo("提示", f"跳转失败: {str(e)}")

    def on_click_jump_cos(self):
        try:
            if self.process_count < len(self.cos_index):
                target_id = int(self.cos_index[self.process_count])
                self.process_count = target_id
                self.c.execute("UPDATE process SET id = ?", (self.process_count,))
                self.conn.commit()
                self.load_current_word()
        except Exception as e:
            messagebox.showinfo("提示", f"跳转失败: {str(e)}")

    def on_click_jump(self):
        jump_word = self.jump_input_box.get().strip()
        if not jump_word:
            return
            
        self.c.execute("SELECT * FROM words WHERE word = ?", (jump_word,))
        result = self.c.fetchone()
        if not result:
            messagebox.showinfo('提示', '没有找到该单词')
            self.jump_input_box.delete(0, 'end')
            return
            
        self.process_count = result[0]
        self.c.execute("UPDATE process SET id = ?", (self.process_count,))
        self.conn.commit()
        self.load_current_word()
        self.jump_input_box.delete(0, 'end')

    def load_statistics(self):
        """加载学习统计数据"""
        try:
            # 获取今天的学习记录
            today = datetime.now().strftime('%Y-%m-%d')
            self.c.execute("SELECT count FROM statistics WHERE date = ?", (today,))
            result = self.c.fetchone()
            self.today_count = result[0] if result else 0
            self.last_study_date = today
            
            # 获取最近7天的学习记录
            self.c.execute("SELECT count FROM statistics WHERE date >= date('now', '-6 days') ORDER BY date")
            self.week_counts = deque((row[0] for row in self.c.fetchall()), maxlen=7)
            
            # 确保有7天的数据（不足补0）
            while len(self.week_counts) < 7:
                self.week_counts.appendleft(0)
                
        except Exception as e:
            print(f"加载统计信息失败: {e}")
            self.today_count = 0
            self.week_counts = deque([0]*7, maxlen=7)

    def update_statistics(self):
        """更新学习统计数据"""
        try:
            today = datetime.now().strftime('%Y-%m-%d')
            
            # 如果日期变化，重置今日计数
            if self.last_study_date != today:
                if self.last_study_date:  # 不是第一次学习
                    self.week_counts.append(self.today_count)
                self.today_count = 0
                self.last_study_date = today
                
            # 增加今日计数
            self.today_count += 1
            
            # 更新数据库
            self.c.execute('''
                INSERT OR REPLACE INTO statistics (date, count)
                VALUES (?, ?)
            ''', (today, self.today_count))
            self.conn.commit()
            
            # # 同步数据到云端
            # self.publish_statistics()
            
        except Exception as e:
            print(f"更新统计信息失败: {e}")

    def update_statistics_data(self):
        """实时更新统计数据字典"""
        try:
            # 总单词数
            self.c.execute("SELECT COUNT(*) FROM words")
            self.statistics_data["total_words"] = self.c.fetchone()[0]
            
            # 已掌握单词数（count >= 3）
            self.c.execute("SELECT COUNT(*) FROM words WHERE count >= 3")
            self.statistics_data["mastered_words"] = self.c.fetchone()[0]
            
            # 待背单词数 = 总单词数 - 已掌握单词数
            self.statistics_data["remaining_words"] = (
                self.statistics_data["total_words"] - 
                self.statistics_data["mastered_words"]
            )
            
            # 今日已掌握单词数（通过统计当天学习记录）
            today = datetime.now().strftime('%Y-%m-%d')
            self.c.execute("""
                SELECT COUNT(*) FROM words 
                WHERE count >= 3 
                AND last_updated LIKE ? || '%'
            """, (today,))
            self.statistics_data["today_mastered"] = self.c.fetchone()[0]
            
        except Exception as e:
            print(f"更新统计数据失败: {e}")

    def start_eeg_data_upload(self):
        """启动脑机数据定时上传"""
        self.upload_eeg_data()  # 立即上传一次
        # 设置定时器，每1秒上传一次
        self.eeg_upload_timer = self.root.after(
            self.eeg_upload_interval, 
            self.start_eeg_data_upload
        )
    
    def upload_eeg_data(self):
        """上传脑机数据到云端"""
        try:
            if not hasattr(self, 'eeg_monitor') or not self.eeg_monitor.last_attention_value:
                return
                
            # 使用TuyaMQTTManager的publish_attention方法
            success = self.mqtt_client.publish_attention(
                self.eeg_monitor.last_attention_value
            )
            
            if not success:
                print("脑机数据上传失败，将重试")
            
        except Exception as e:
            print(f"上传脑机数据异常: {str(e)}")

    def show_statistics(self):
        try:
            total_words = self.statistics_data["total_words"]
            mastered = self.statistics_data["mastered_words"]
            remaining = self.statistics_data["remaining_words"]
            today_mastered = self.statistics_data["today_mastered"]  # 当天掌握数
            today_studied = self.today_count  # 当天学习总数（可选显示）
            
            stats = (
                f"总单词数: {total_words}\n"
                f"已掌握单词: {mastered}\n"
                f"待背单词: {remaining}\n"
                f"今日掌握单词: {today_mastered}\n"
                f"今日学习单词: {today_studied}"
            )
            
            messagebox.showinfo("学习统计", stats)
            
        except Exception as e:
            messagebox.showerror("错误", f"获取统计信息失败: {str(e)}")

    def publish_statistics(self):
        """
        手动同步统计数据到云平台
        """
        try:
            if not self.mqtt_client.connected:
                if not self.mqtt_client.connect():
                    messagebox.showerror("错误", "MQTT连接失败，无法同步数据")
                    return False

            # 更新本地统计数据
            self.update_statistics_data()
            current_time = str(int(time.time())) + "000"

            # 严格对齐 C++ 的 JSON 结构
            payload = "{"
            payload += "\"msgId\":\"sensor_data_report_001\","
            payload += "\"time\":\"" + current_time + "000\","

            payload += "\"data\":{"
            payload += "\"total_words\":{"
            payload += "\"value\":\"" + str(self.statistics_data["total_words"]) + "\","
            payload += "\"time\":\"" + current_time + "000\""
            payload += "},"
            payload += "\"mastered_words\":{"
            payload += "\"value\":\"" + str(self.statistics_data["mastered_words"]) + "\","
            payload += "\"time\":\"" + current_time + "000\""
            payload += "},"
            payload += "\"remaining_words\":{"
            payload += "\"value\":\"" + str(self.statistics_data["remaining_words"]) + "\","
            payload += "\"time\":\"" + current_time + "000\""
            payload += "},"
            payload += "\"today_mastered\":{"
            payload += "\"value\":\"" + str(self.statistics_data["today_mastered"]) + "\","
            payload += "\"time\":\"" + current_time + "000\""
            payload += "},"  

            #  脑机数据字段
            if hasattr(self, 'eeg_monitor') and getattr(self.eeg_monitor, 'last_attention_value', None):
                payload += "\"attention_value\":{"
                payload += "\"value\":\"" + str(round(self.eeg_monitor.last_attention_value, 2)) + "\","
                payload += "\"time\":\"" + current_time + "000\""
                payload += "}"
            else:
                payload = payload.rstrip(',')  # 若无脑机数据则移除末尾逗号

            payload += "}"
            payload += "}"

            topic = f"tylink/{self.TUYA_DEVICE_ID}/thing/property/report"
            result = self.mqtt_client.client.publish(topic, payload, qos=1)  

            if result.rc != mqtt.MQTT_ERR_SUCCESS:
                messagebox.showerror("错误", f"发布失败: {mqtt.error_string(result.rc)}")
                return False

            messagebox.showinfo("成功", "数据已同步到涂鸦云")
            return True

        except Exception as e:
            messagebox.showerror("错误", f"数据同步异常: {str(e)}")
            return False

    def upload_mastered_word(self):
        """
        上传已掌握的单词到云平台（仅timestamp_word字段）
        """
        try:
            if not self.mqtt_client.connected:
                if not self.mqtt_client.connect():
                    print("MQTT连接失败，无法上传单词")
                    return False

            # 获取当前单词
            self.c.execute("SELECT word FROM words WHERE id = ?", (self.process_count,))
            word = self.c.fetchone()[0]
            current_time = str(int(time.time())) + "000"

            # 严格字符串拼接（仅timestamp_word字段）
            payload = "{"
            payload += "\"msgId\":\"mastered_word_report\","
            payload += "\"time\":\"" + current_time + "\","

            payload += "\"data\":{"
            payload += "\"timestamp_word\":{"
            payload += "\"value\":\"" + current_time + "_" + str(word) + "\","
            payload += "\"time\":\"" + current_time + "000\""
            payload += "}"

            payload += "}"
            payload += "}"

            topic = f"tylink/{self.TUYA_DEVICE_ID}/thing/property/report"
            result = self.mqtt_client.client.publish(topic, payload, qos=1)

            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                print(f"成功上传单词标识符: {current_time}_{word}")
                return True
            else:
                print(f"上传失败: {mqtt.error_string(result.rc)}")
                return False

        except Exception as e:
            print(f"上传异常: {str(e)}")
            return False

    def _handle_batch_completion(self):
        """批处理完成时生成短文"""
        batch_words = [self.c.execute("SELECT word FROM words WHERE id=?", (wid,)).fetchone()[0]
                    for wid in self.current_batch]
        
        # 显示等待提示
        wait_window = tk.Toplevel(self.root)
        wait_window.title("请稍候")
        wait_window.geometry("300x100")
        tk.Label(
            wait_window, 
            text="正在生成短文.....请稍后!", 
            font=("微软雅黑", 14)
        ).pack(expand=True, fill="both", padx=20, pady=20)
        
        # 强制更新界面显示提示
        wait_window.update_idletasks()
        
        try:
            essay = self.essay_generator.generate_essay(batch_words)
            
            # 关闭等待窗口
            wait_window.destroy()
            
            # 原有错误处理和高亮逻辑保持不变
            if "失败" in essay or "错误" in essay:
                messagebox.showwarning("生成警告", essay)
            else:
                self._display_essay(essay, batch_words)  # 保持原有高亮显示
        except Exception as e:
            # 确保在出错时也关闭等待窗口
            wait_window.destroy()
            messagebox.showerror("错误", f"生成短文时出错: {str(e)}")
        
        self.current_batch = []
    
    def _display_essay(self, essay, words):
        """显示短文并高亮所有单词"""
        essay_window = tk.Toplevel(self.root)
        essay_window.title("生成的英语短文")
        essay_window.geometry("750x450")
        
        # 顶部信息区域
        info_frame = tk.Frame(essay_window)
        info_frame.pack(fill="x", padx=10, pady=5)
        
        # 单词列表
        tk.Label(
            info_frame, 
            text="必须包含的单词: ", 
            font=("微软雅黑", 12, "bold")
        ).pack(side="left")
        
        tk.Label(
            info_frame, 
            text=f", ".join(words), 
            font=("微软雅黑", 12, "italic"),
            fg="blue"
        ).pack(side="left", padx=5)
        
        # 短文内容区域
        text_frame = tk.Frame(essay_window)
        text_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        scrollbar = tk.Scrollbar(text_frame)
        scrollbar.pack(side="right", fill="y")
        
        essay_text = tk.Text(
            text_frame,
            wrap="word",
            font=("微软雅黑", 11),
            padx=10, 
            pady=10,
            yscrollcommand=scrollbar.set
        )
        essay_text.pack(fill="both", expand=True)
        scrollbar.config(command=essay_text.yview)
        
        # 插入短文并高亮单词
        essay_text.insert("1.0", essay)
        
        # 高亮每个单词（大小写不敏感）
        for word in words:
            self._highlight_word(essay_text, word)
        
        essay_text.config(state="disabled")  # 只读模式
        
        # 关闭按钮
        tk.Button(
            essay_window, 
            text="关闭", 
            command=essay_window.destroy,
            width=10,
            height=1
        ).pack(pady=10)
    
    def _highlight_word(self, text_widget, word):
        """高亮单词（大小写不敏感）"""
        start = "1.0"
        word_lower = word.lower()
        
        while True:
            # 不区分大小写搜索
            start = text_widget.search(
                word_lower, 
                start, 
                stopindex="end", 
                nocase=True
            )
            if not start:
                break
                
            end = f"{start}+{len(word)}c"
            text_widget.tag_add("highlight", start, end)
            start = end
        
        # 高亮样式：黄色背景+加粗
        text_widget.tag_config("highlight", 
            background="yellow", 
            foreground="black",
            font=("微软雅黑", 11, "bold")
        )

    def start_eeg_monitoring(self):
        """启动脑电监测线程"""
        import threading
        self.eeg_thread = threading.Thread(
            target=self.eeg_monitor.start,
            daemon=True  # 随主程序退出自动结束
        )
        self.eeg_thread.start()

    def check_connection(self):
        """简化版连接检测"""
        is_connected = self.eeg_monitor.check_connection()
        status = "✅ 已连接" if is_connected else "❌ 未连接"
        self.connection_label.config(
            text=f"脑机状态: {status}",
            fg="green" if is_connected else "red"
        )
        # self.root.after(10000, self.check_connection)  # 每2秒检测一次

def main():
    """主函数，程序入口点"""
    root = tk.Tk()
    app = WordReciteApp(root)

    # # ====================== 一次性重置代码（执行后注释掉） ======================
    # try:
    #     # 1. 重置所有单词的掌握次数为 0，并清空最后更新时间
    #     app.c.execute("UPDATE words SET count = 0, last_updated = NULL")
        
    #     # 2. 清空已掌握单词集合
    #     app.mastered_words = set()
        
    #     # 3. 更新已掌握单词计数
    #     app.learned_word_count = 0
    #     app.learned_str_count.set(f"{app.learned_word_count}/{app.word_count}")
        
    #     # 4. 重置学习进度为第一个单词（安全处理空表情况）
    #     app.c.execute("SELECT id FROM words ORDER BY id ASC LIMIT 1")
    #     result = app.c.fetchone()
    #     first_word_id = result[0] if result else 0
    #     app.c.execute("DELETE FROM process")
    #     app.c.execute("INSERT INTO process VALUES (?)", (first_word_id,))
        
    #     # 5. 清空统计数据
    #     app.c.execute("DELETE FROM statistics")
    #     app.today_count = 0
    #     app.week_counts = deque([0]*7, maxlen=7)
        
    #     # 6. 更新统计数据字典
    #     app.update_statistics_data()
        
    #     # 7. 提交修改
    #     app.conn.commit()
    #     print("学习记录已重置")
        
    # except Exception as e:
    #     app.conn.rollback()
    #     print(f"重置失败: {e}")
    # # ====================== 注释结束 ======================

    root.mainloop()

if __name__ == "__main__":
    main()